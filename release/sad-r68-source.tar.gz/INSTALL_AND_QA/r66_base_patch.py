#!/usr/bin/env python3
"""Offline integrator for a checked-out gh-rab LSH repository.

DRY RUN by default. This script never accesses GitHub or deploys. Apply only to a
separate branch/copy after PR #101/R64 has been assessed/merged. Every original
file modified is copied to --backup-dir before writes; copyback is possible.
"""
from __future__ import annotations
import argparse,datetime,hashlib,json,shutil,sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parents[1]
SUB = Path('language-skills-hub')
FILES_TO_COPY = [
 'poslech/sad/index.html','poslech/sad/sad-data.js','poslech/sad/sad-core.js','poslech/sad/sad-practice.js','poslech/sad/sad.css',
 'poslech/sad/teacher-key.html','poslech/sad/teacher-key.js','poslech/sad/sad-test.css',
 'self-check/listening/sad-student.html','self-check/listening/sad-student.js',
 'tests/r65-sad.test.cjs','tests/r65-sad.browser.test.cjs'
]

def change_one(content: str, before: str, after: str, why: str) -> str:
 count=content.count(before)
 if count!=1: raise RuntimeError(f'{why}: expected exactly one source match, found {count}; review code before adapting')
 return content.replace(before,after,1)

def read_json(p):return json.loads(p.read_text(encoding='utf-8'))

def patch(repo: Path):
 hub=repo/SUB
 needed=['data/cards.json','data/catalog-i18n.json','assets/hub.js','index.html',
         'version.json','self-check/listening/listening-teacher.js']
 for relative in needed:
  if not (hub/relative).is_file():raise RuntimeError('Missing LSH file: '+str(hub/relative))
 # Fail without partial mutation on conflicts with an earlier SAD edition.
 if (hub/'poslech/sad/index.html').exists() or (hub/'self-check/listening/sad-student.html').exists():
  raise RuntimeError('SAD already exists in this checkout; compare changes manually (installation not repeated)')
 cards=read_json(hub/'data/cards.json')
 if any(e.get('id')=='ll-sad' for e in cards.get('entries',[])):
  raise RuntimeError('ll-sad already in catalogue; stop rather than duplicate')
 if cards.get('kind')!='LSH_PUBLIC_PRACTICE_R17':raise RuntimeError('Unexpected catalog contract')
 if len(cards['entries'])!=30 or sum(len(e['languages'])*len(e['levels']) for e in cards['entries'])!=666 or not any(e['id']=='cl-human-rights' for e in cards['entries']):
  raise RuntimeError('Expected current Human Rights R35-HR2 baseline: 30 topics / 666 variants; review GitHub state before installing.')
 old_topics=len(cards['entries']);old_variants=sum(len(e['languages'])*len(e['levels']) for e in cards['entries'])
 old_counts={skill:sum(e['skill']==skill for e in cards['entries']) for skill in ['konverzace','cteni','poslech']}
 cards['entries'].append({
  'id':'ll-sad','skill':'poslech',
  'title':'Seasonal Affective Disorder – Winter got you feeling down?',
  'summary':'Autentické TED-Ed video o sezonní afektivní poruše: biologické rytmy, hypotézy, detaily a kritické porozumění.',
  'languages':['en'],'levels':['B2','C1'],'relative':'poslech/sad/index.html','lockSource':None
 })
 translations=read_json(hub/'data/catalog-i18n.json')
 if 'll-sad' in translations['entries']:raise RuntimeError('SAD translation already exists')
 translations['entries']['ll-sad']={
  'cs':{'title':'Sezónní afektivní porucha – Winter got you feeling down?',
   'summary':'TED-Ed: porozumění odbornému poslechu, posuzování hypotéz a rozlišení pravdivých, nepravdivých a neuvedených informací.'},
  'en':{'title':'Seasonal Affective Disorder – Winter got you feeling down?',
   'summary':'TED-Ed listening about seasonal depression, circadian hypotheses, factual details and scientific uncertainty.'}
 }
 if len(translations['entries'])!=len(cards['entries']):raise RuntimeError('Card/translation counts differ')
 new={
  'data/cards.json':json.dumps(cards,ensure_ascii=False,indent=2)+'\n',
  'data/catalog-i18n.json':json.dumps(translations,ensure_ascii=False,indent=2)+'\n'
 }
 js=(hub/'assets/hub.js').read_text(encoding='utf-8')
 # Relax hard-coded 29-item contract, but retain structural and translation checks.
 js=change_one(js,"body.entries.length!==30","body.entries.length<1||body.entries.length>200",
   'dynamic catalogue size')
 js=change_one(js,"Object.keys(i18n.entries).length!==30","Object.keys(i18n.entries).length!==body.entries.length",
   'dynamic i18n size')
 needle="function practiceKeyUrl(e){\n if(!['cteni','poslech'].includes(e.skill))return '';"
 add="""function practiceKeyUrl(e){
 if(!['cteni','poslech'].includes(e.skill))return '';
 if(e.id==='ll-sad'){
  const url=new URL('poslech/sad/teacher-key.html',document.baseURI);
  const level=byId('level').value;
  if(e.levels.includes(level))url.searchParams.set('level',level);
  return url.href;
 }"""
 js=change_one(js,needle,add,'SAD teacher key route')
 new['assets/hub.js']=js
 index=(hub/'index.html').read_text(encoding='utf-8')
 index=change_one(index,'29 témat, interaktivní procvičování','31 témat, interaktivní procvičování','index description')
 index=change_one(index,'<strong>21</strong><span>Conversation</span>','<strong>22</strong><span>Conversation</span>','index welcome conversation count')
 index=change_one(index,'<span class="chooser-count">21 témat','<span class="chooser-count">22 témat','index chooser conversation count')
 index=change_one(index,'<strong>3</strong><span>Listening</span>','<strong>4</strong><span>Listening</span>','index welcome count')
 index=change_one(index,'<span class="chooser-count">3 témata','<span class="chooser-count">4 témata','index chooser count')
 new['index.html']=index
 teacher=(hub/'self-check/listening/listening-teacher.js').read_text(encoding='utf-8')
 marker="  'll-peaky-no-fighting':{"
 before=marker
 insert="""  'll-sad':{
   title:'Seasonal Affective Disorder · TED-Ed',
   source:'poslech/sad/index.html',
   levels:['B2','C1'],
   media:[
    {key:'youtube',url:'https://www.youtube.com/watch?v=0RiDPisQAzM',label:'Přehrát originál TED-Ed na YouTube'},
    {key:'teded',url:'https://ed.ted.com/lessons/how-to-tell-if-you-have-seasonal-affective-disorder-kelly-rohan',label:'Oficiální lekce TED-Ed (alternativa)'}
   ],
   caution:'Obsahové upozornění: video hovoří o depresi a zmiňuje sebevražedné myšlenky. Nevyžadujte osobní zdravotní zkušenosti žáků.'
  },
"""+marker
 teacher=change_one(teacher,before,insert,'teacher SAD entry')
 teacher=change_one(teacher, "'facebook.com','x.com'].includes(url.hostname)",
  "'facebook.com','x.com','ed.ted.com'].includes(url.hostname)",
  'allow official TED-Ed lesson host (HTTPS only)')
 teacher=change_one(teacher,"const u=new URL('student.html',location.href);",
  "const u=new URL(topicId==='ll-sad'?'sad-student.html':'student.html',location.href);",'student destination')
 teacher=change_one(teacher,'!core.LEVELS.includes(level)){',
  "!core.LEVELS.includes(level)||(chosen.levels&&!chosen.levels.includes(level))){",'teacher level guards')
 teacher=change_one(teacher,"  $('level').value=core.LEVELS.includes(params.get('level'))?params.get('level'):'B2';",
  """  const allowed=chosen.levels||core.LEVELS;
  for(const option of $('level').options){
   option.disabled=!allowed.includes(option.value);
   option.hidden=!allowed.includes(option.value);
  }
  $('level').value=allowed.includes(params.get('level'))?params.get('level'):
   (allowed.includes('B2')?'B2':allowed[0]);""",'teacher allowed level options')
 new['self-check/listening/listening-teacher.js']=teacher
 version=read_json(hub/'version.json')
 version['topicCount']=len(cards['entries'])
 if not isinstance(version.get('variantCount'),int):raise RuntimeError('Unexpected variant count in version.json')
 version['variantCount']=old_variants+2
 version.setdefault('contentHashes',{})['ll-sad']=hashlib.sha256((BUNDLE/SUB/'poslech/sad/index.html').read_bytes()).hexdigest()
 version['sadSource']='SAD-B2C1-20261109-v1 · one original 17-question bank for B2 and C1'
 version['sadBankSha256']=hashlib.sha256((BUNDLE/'AUTHORING/sad-source-bank.js').read_bytes()).hexdigest()
 new['version.json']=json.dumps(version,ensure_ascii=False,indent=2)+'\n'

 # R65: adapt historic regression assertions without reducing coverage of
 # their ORIGINAL cohorts. The three legacy Listening sources still have 18
 # A1-C2 variants; ll-sad is independently tested by r65-sad.test.cjs.
 # The original release integrity SHA checks now also cover the new card.
 def amend_test(filename,changes):
  path=hub/'tests'/filename
  if not path.is_file():
   # R64 is not present in current main, but will be present after PR #101.
   if filename.startswith('r64-'):return
   raise RuntimeError('Missing required regression test: '+str(path))
  value=path.read_text(encoding='utf-8')
  for older,newer,label in changes:
   value=change_one(value,older,newer,'test '+filename+': '+label)
  new['tests/'+filename]=value
 def repl(a,b,why):return (a,b,why)
 # Exact counts of the expanded CANONICAL catalogue (HR2 baseline 30/666 -> 31/668). Keep sha256 assertions.
 for filename,items in {
  'r22-static-policy.test.cjs':[
   repl('catalog.entries.length, 30','catalog.entries.length, 31','count'),
   repl('release.topicCount, 30','release.topicCount, 31','topic count'),
   repl('release.variantCount, 666','release.variantCount, 668','variant count'),
   repl('variants, 666','variants, 668','variant count'),
   repl('poslech:3','poslech:4','skill counts')],
  'r23-reading-selfcheck.test.cjs':[
   repl('cards.entries.length,30','cards.entries.length,31','count'),
   repl('count,666','count,668','variant count')],
  'r24-listening-selfcheck.test.cjs':[
   repl("cards.entries.filter(x=>x.skill==='poslech')", "cards.entries.filter(x=>x.skill==='poslech'&&core.TOPICS.includes(x.id))",'legacy Listening cohort'),
   repl('cards.entries.length,30','cards.entries.length,31','count'),
   repl('0),666','0),668','variant count')],
  'r25-result-contract.test.cjs':[
   repl("catalog.entries.filter(x=>x.skill==='poslech')", "catalog.entries.filter(x=>x.skill==='poslech'&&x.id!=='ll-sad')",'legacy Listening cohort'),
   repl('catalog.entries.length,30','catalog.entries.length,31','count'),
   repl('0),666','0),668','variant count')],
  'r27-public-release.test.cjs':[
   repl('catalog.entries.length,30','catalog.entries.length,31','count'),
   repl('manifest.topicCount,30','manifest.topicCount,31','topic count'),
   repl('manifest.variantCount,666','manifest.variantCount,668','variant count'),
   repl('poslech:3','poslech:4','skill counts'),
   repl('variants,666','variants,668','variant count')],
  'r39-catalog-cefr-badges.test.cjs':[
   repl('catalog.length,30','catalog.length,31','count'),
   repl('poslech:3','poslech:4','skill counts')],
  'r40-vocabulary-integration.test.cjs':[
   repl('catalog.length,30','catalog.length,31','count'),
   repl('[22,5,3]','[22,5,4]','skill counts')],
  'r43-backup-safety.test.cjs':[
   repl('v.topicCount,30','v.topicCount,31','count'),
   repl('v.variantCount,666','v.variantCount,668','variant count')],
  'r49-unified-vocabulary.test.cjs':[
   repl('data.length,30','data.length,31','count'),
   repl('[22,5,3]','[22,5,4]','skill counts')],
  'r58-reading-test-tabs.test.cjs':[
   repl('catalog.entries.length,30','catalog.entries.length,31','count')],
  # HR2 remains byte-identical and cryptographically pinned; only the catalogue grows.
  'r35-hr2-release.test.cjs':[
   repl('catalog.entries.length,30','catalog.entries.length,31','count'),
   repl('version.topicCount,30','version.topicCount,31','topic count'),
   repl('version.variantCount,666','version.variantCount,668','variant count'),
   repl('catalog.entries.reduce((n,x)=>n+x.languages.length*x.levels.length,0),666','catalog.entries.reduce((n,x)=>n+x.languages.length*x.levels.length,0),668','variant count'),
   repl('i18n.entries).length,30','i18n.entries).length,31','i18n count'),
   repl('version.contentHashes).length,30','version.contentHashes).length,31','hash count'),
   repl(r'assert.match(hubjs,/body\.entries\.length!==30/);',r'assert.match(hubjs,/body\.entries\.length>200/);','robust count bound'),
   repl(r'assert.match(hubjs,/Object\.keys\(i18n\.entries\)\.length!==30/);',r'assert.match(hubjs,/Object\.keys\(i18n\.entries\)\.length!==body\.entries\.length/);','dynamic i18n validation'),
   repl("0),666'));","0),668'));",'historic R24 updated count')]
 }.items():amend_test(filename,items)
 # R64 is a separate pending PR based on older main. If already rebased/merged,
 # its assert must match the source release; do not silently edit an old PR branch.
 r64=hub/'tests/r64-real-catalog-sources.test.cjs'
 if r64.is_file():
  v=r64.read_text('utf-8')
  if 'entries.length,30' not in v:raise RuntimeError('R64 test expects an incompatible source; rebase PR #101 first.')
  amend_test('r64-real-catalog-sources.test.cjs',[
   repl('entries.length,30','entries.length,31','expanded catalogue')])
 # Existing test engines and teacher-key snapshot are deliberately frozen to
 # 3 original Listening modules. ll-sad has its own independent contract.
 tests_to_scope={
  'r28-grade-proposal.test.cjs': ["catalog.entries.filter(x=>x.skill==='poslech')"],
  'r33-auto-listening-and-export.test.cjs':["catalog.entries.filter(e=>e.skill==='poslech')"],
  'r36-practice-answer-keys.test.cjs':[
   ".filter(x=>['cteni','poslech'].includes(x.skill))"],
  'r37-case-insensitive-listening-cloze.test.cjs':[
   "catalog.entries.filter(e=>e.skill==='poslech')"],
  'r38-listening-answer-integrity.browser.test.cjs':[
   ".entries.filter(e=>e.skill==='poslech')"],
  'r38-listening-answer-integrity.test.cjs':[
   "catalog.entries.filter(e=>e.skill==='poslech')"],
  'r42-listening-vocabulary.browser.test.cjs':[
   ".filter(x=>x.skill==='poslech')"],
  'r48-errors-only-feedback.test.cjs':[
   "catalog.entries.filter(x=>x.skill==='poslech')"],
  'r50-fixed-topic-results.test.cjs':[
   "entries.filter(e=>['cteni','poslech'].includes(e.skill))"],
  'r50-fixed-topic-results.browser.test.cjs':[
   "entries.filter(e=>['cteni','poslech'].includes(e.skill))"],
  'r51-dual-mode-answer-keys.test.cjs':[
   "entries.filter(e=>['cteni','poslech'].includes(e.skill))"],
  'r52-resilient-teacher-key.test.cjs':[
   "entries.filter(e=>['cteni','poslech'].includes(e.skill))"],
  'r53-listening-fixed-topic-video.test.cjs':[
   "entries.filter(e=>e.skill==='poslech')"],
  'r53-listening-fixed-topic-video.browser.test.cjs':[
   "entries.filter(e=>e.skill==='poslech')"],
  'r64-listening-cloze-fairness.test.cjs':[
   "entries.filter(e=>e.skill==='poslech')"],
 }
 for filename,patterns in tests_to_scope.items():
  updates=[]
  for src in patterns:
   if filename=='r53-listening-fixed-topic-video.test.cjs':
    dest=src.replace("e.skill==='poslech'", "e.skill==='poslech'&&core.TOPICS.includes(e.id)")
   elif "poslech" in src and "['cteni','poslech']" not in src:
    dest=src.replace("skill==='poslech'", "skill==='poslech'&&"+('e' if "e.skill" in src else 'x')+".id!=='ll-sad'")
   else:
    dest=src.replace('.includes(e.skill))', ".includes(e.skill)&&e.id!=='ll-sad')") if 'e.skill' in src else src.replace('.includes(x.skill))', ".includes(x.skill)&&x.id!=='ll-sad')")
   updates.append(repl(src,dest,'preserve legacy cohort'))
  if filename=='r53-listening-fixed-topic-video.test.cjs':
   updates.append(repl(r"assert.match(js,/new URL\('student\.html',location\.href\)/);", r"assert.match(js,/sad-student\.html/);",'SAD test url'))
  amend_test(filename,updates)
 return new

def main():
 arg=argparse.ArgumentParser(description=__doc__)
 arg.add_argument('--repo',required=True,type=Path,help='root of a checked-out gh-rab github.io repo')
 arg.add_argument('--apply',action='store_true',help='otherwise only validate/dry run')
 arg.add_argument('--backup-dir',type=Path,help='optional backup directory, outside production root recommended')
 cfg=arg.parse_args()
 repo=cfg.repo.resolve()
 updates=patch(repo)
 print('SAD integration plan:')
 for path in sorted(FILES_TO_COPY):print(' +',SUB/path)
 for path in sorted(updates):print(' ~',SUB/path)
 print('Source catalogue: 3 -> 4 Listening topics; 30 -> 31 catalogue topics; 666 -> 668 variants; test B2/C1 only.')
 if not cfg.apply:
  print('DRY RUN ONLY. No files changed. Use --apply on a review branch after R64 evaluation.')
  return
 date=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%SZ')
 backups=(cfg.backup_dir or (BUNDLE/'INSTALL_AND_QA'/'backups'/date)).resolve()
 if backups.is_relative_to(repo):raise RuntimeError('Backup directory must not be within the target repository')
 for relative in updates:
  original=repo/SUB/relative;dest=backups/SUB/relative
  dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,dest)
 for relative in FILES_TO_COPY:
  origin=BUNDLE/SUB/relative;dest=repo/SUB/relative
  if not origin.is_file():raise RuntimeError('Missing package file: '+str(origin))
  dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin,dest)
 for relative,txt in updates.items():
  p=repo/SUB/relative;p.write_text(txt,encoding='utf-8')
 print('APPLIED on local files only. Originals backed up to:',backups)
 print('Next: run Node/Playwright regressions, check real iPad and review the git diff; DO NOT deploy until GO.')

if __name__=='__main__':
 try:main()
 except Exception as error:print('INSTALLATION STOPPED:',error,file=sys.stderr);sys.exit(2)
