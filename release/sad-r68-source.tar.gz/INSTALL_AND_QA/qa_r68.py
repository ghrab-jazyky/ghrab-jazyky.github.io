#!/usr/bin/env python3
"""R68 independent source/CEFR audit. Requires Python3 + Node. No browser/network/deployment."""
from __future__ import annotations
import base64,hashlib,json,re,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'language-skills-hub/poslech/sad'
LEVELS=['A1','A2','B1','B2','C1','C2']
def stop(ok,description):
 if not ok:raise AssertionError(description)
def extract(script,label):
 match=re.search(r'\bconst\s+'+re.escape(label)+r'\s*=',script)
 stop(match is not None,label+' missing')
 return json.JSONDecoder().raw_decode(script[match.end():].strip())[0]
def main():
 html=(SRC/'index.html').read_text('utf-8')
 inline=re.findall(r'<script>([\s\S]*?)</script>',html)
 stop(len(inline)==1,'Expected one inline DATA/SOURCES script')
 data=extract(inline[0],'DATA');sources=extract(inline[0],'SOURCES')
 original=extract((ROOT/'AUTHORING/sad-source-bank.js').read_text('utf-8'),'DATA')
 authored=json.loads((ROOT/'AUTHORING/sad-R68-A1-C2.json').read_text('utf-8'))
 stop(data['levels']==LEVELS,'six CEFR levels missing')
 stop(list(data['variants'])==LEVELS,'variant-bank order mismatch')
 stop(data['questionBank']==original['questionBank'],'original B2 question bank modified')
 stop(data['matchingBank']==original['matchingBank'],'original B2 matching options modified')
 stop(data['variants']['B2']['questionBank']==original['questionBank'],'B2 assessment drift')
 stop(data['variants']['B2']['matchingBank']==original['matchingBank'],'B2 matching drift')
 stop(sources['teded']==original['source'] and sources['youtube']==original['video'],'video source drift')
 digest=base64.b64encode(hashlib.sha256(inline[0].encode('utf-8')).digest()).decode('ascii')
 stop("'sha256-"+digest+"'" in html,'CSP SHA256 mismatch')
 stop(len(html.encode('utf-8'))<=200000,'Core extractJson source exceeds 200 KB')
 buttons=re.findall(r'<button[^>]+data-level="(A1|A2|B1|B2|C1|C2)"',html)
 stop(buttons==LEVELS,'practice selector not exactly six levels')
 stop('card-vocabulary.js' in html,'shared vocabulary module missing')
 stop('sad-student.html' not in html,'retired dedicated student route still referenced')
 stop('teacher-key.html' not in html,'retired teacher route still referenced')
 per_level={},
 b2_hash=hashlib.sha256(json.dumps(original['questionBank'],ensure_ascii=False,sort_keys=True).encode('utf-8')).hexdigest()
 questions=[]
 for level in LEVELS:
  variant=data['variants'][level]
  typed={t:sum(x['type']==t for x in variant['questionBank']) for t in ['mc','tns','match']}
  stop(typed=={'mc':6,'tns':6,'match':5},level+' wrong distribution '+str(typed))
  stop([x['id'] for x in variant['questionBank']]==[s+str(i) for s,lim in [('A',6),('B',6),('C',5)] for i in range(1,lim+1)],level+' item IDs drift')
  stop(len(variant['matchingBank'])==7,level+' matching distractors missing')
  stop(len(set(q['correct'] for q in variant['questionBank'] if q['type']=='match'))==5,level+' matching correct letters not unique')
  stop(set(q['correct'] for q in variant['questionBank'] if q['type']=='tns')=={'TRUE','FALSE','NOT STATED'},level+' TNS imbalance')
  stop(all(q.get('evidence') and q.get('explanation') for q in variant['questionBank']),level+' missing evidence')
  stop(variant==authored['variants'][level],level+' published bank differs from authored source')
  stop(data[level]['matching']['items'] and len(data[level]['matching']['items'])==5,level+' LSH mapping absent')
  stop(len(data['practice'][level]['vocabulary'])==6,level+' lesson vocab absent')
  questions.extend(q['question'] for q in variant['questionBank'])
 stop(len(questions)==102,'wrong authored total')
 for rel in ['sad-core.js','sad-practice.js']:
  p=SRC/rel
  check=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
  stop(check.returncode==0,rel+': syntax error '+check.stderr)
 for rel in ['r68-sad-a1c2.test.cjs','r68-sad-a1c2.browser.test.cjs']:
  p=ROOT/'language-skills-hub/tests'/rel
  check=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
  stop(check.returncode==0,rel+': syntax error '+check.stderr)
 script=ROOT/'INSTALL_AND_QA/qa_r68_node.cjs'
 check=subprocess.run(['node',str(script)],capture_output=True,text=True)
 stop(check.returncode==0,'node bank audit failed: '+check.stderr+' / '+check.stdout)
 print(check.stdout.strip())
 print('PASS: Python source audit, six unique banks, original B2 keys, CSP, 102 objective questions, JS syntax.')
 print('SKIP: full live LSH, browser integration, iPad/WebKit, final hearing check of newly authored CEFR distractors.')
 print('B2 hash:',b2_hash)
if __name__=='__main__':
 try:main()
 except Exception as e:
  print('QA FAIL:',e,file=sys.stderr);sys.exit(1)
