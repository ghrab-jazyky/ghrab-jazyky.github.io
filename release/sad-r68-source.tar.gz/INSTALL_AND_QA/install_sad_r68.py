#!/usr/bin/env python3
"""R68 SAD A1-C2: fail-closed integration into the ONE canonical LSH Listening stack.

DRY-RUN default; explicit --apply only on separate checkout/review branch.
Fails if checkout is not the pinned 30-card, 666-variant HR2 production baseline.
No remote writes, no git commands, no production deployment.
"""
from __future__ import annotations
import argparse,datetime,hashlib,importlib.util,json,re,shutil,sys,difflib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SUB=Path('language-skills-hub')
LEGACY=Path(__file__).resolve().parent/'install_sad_unified.py'
sp=importlib.util.spec_from_file_location('r67_internal',LEGACY)
r67=importlib.util.module_from_spec(sp);sys.modules[sp.name]=r67;sp.loader.exec_module(r67)
r67.ROOT=ROOT;r67.base.BUNDLE=ROOT
LEVELS=['A1','A2','B1','B2','C1','C2']
COPIES=['poslech/sad/index.html','poslech/sad/sad-core.js','poslech/sad/sad-practice.js','poslech/sad/sad.css',
        'tests/r68-sad-a1c2.test.cjs','tests/r68-sad-a1c2.browser.test.cjs']

def unique(s,old,new,label):return r67.one(s,old,new,label)
def read(repo,rel):return (repo/SUB/rel).read_text(encoding='utf-8')
def swap_all_counts(s):
 # Only replace in source files modified by the R67 compatibility adapter, not in unrelated HTML cards.
 return re.sub(r'(?<!\d)668(?!\d)','672',s)

def add_browser_guard(changes,repo):
 # These files were missed in R67 and are essential to prevent legacy red CI after an extra Listening topic.
 corrections={
  'r27-public-release.browser.test.cjs':[
   ("['konverzace',0],['cteni',5],['poslech',3]","['konverzace',0],['cteni',5],['poslech',4]"),
  ],
  'r45-test-ui-layout.browser.test.cjs':[
   ("['ll-matthew-oscars','ll-harrison-ford','ll-peaky-no-fighting']",
    "['ll-matthew-oscars','ll-harrison-ford','ll-peaky-no-fighting','ll-sad']"),
   ("['cteni',5],['poslech',3],['konverzace',0]",
    "['cteni',5],['poslech',4],['konverzace',0]"),
  ],
  'r39-catalog-cefr-badges.browser.test.cjs':[
   ("{skill:'poslech',lang:'en',alternative:null,count:3}","{skill:'poslech',lang:'en',alternative:null,count:4}"),
  ],
  'r51-dual-mode-answer-keys.browser.test.cjs':[
   ("return v.gist.length+v.detail.length+v.sequence.length+listening.cloze(v,e.id,level).length;",
    "return v.gist.length+v.detail.length+v.sequence.length+(v.matching?.items.length||0)+listening.cloze(v,e.id,level).length;"),
   ("assert.match(await page.locator('#answerPreview').textContent(),/D · Factual cloze – test/);",
    "if(e.id==='ll-sad')assert.match(await page.locator('#answerPreview').textContent(),/Matching – test/);\n      else assert.match(await page.locator('#answerPreview').textContent(),/D · Factual cloze – test/);"),
  ],
 }
 for filename,edits in corrections.items():
  rel='tests/'+filename
  s=changes.get(rel,read(repo,rel))
  for before,after in edits:s=unique(s,before,after,'browser regression '+filename)
  changes[rel]=s

def integrate(repo):
 changes=r67.integrated(repo)
 card=json.loads(changes['data/cards.json']);sad=next(e for e in card['entries'] if e['id']=='ll-sad')
 assert sad['levels']==['B2','C1'] and len(card['entries'])==31
 sad['levels']=LEVELS
 sad['summary']='Autentické TED-Ed video: šest úrovní A1–C2 s vlastními otázkami, procvičováním a automaticky hodnoceným TESTEM.'
 changes['data/cards.json']=json.dumps(card,ensure_ascii=False,indent=2)+'\n'
 i18n=json.loads(changes['data/catalog-i18n.json'])
 i18n['entries']['ll-sad']['cs']['summary']='TED-Ed: šest odstupňovaných poslechů A1–C2; biologické rytmy, vědecké hypotézy a léčebné možnosti.'
 i18n['entries']['ll-sad']['en']['summary']='TED-Ed: six distinct CEFR listening versions A1–C2, from key facts to evaluating scientific hypotheses.'
 changes['data/catalog-i18n.json']=json.dumps(i18n,ensure_ascii=False,indent=2)+'\n'
 version=json.loads(changes['version.json']);version['version']='R68-SAD-A1C2';version['variantCount']=672
 version['sadSource']='Original B2 17-question bank, 5 newly authored level-specific banks, total 102 questions'
 version['sadAssessmentBank']='SAD-R68-A1C2-20261114'
 version['sadCEFRLevels']=LEVELS
 version['sadBankSha256']=hashlib.sha256((ROOT/'AUTHORING/sad-R68-A1-C2.json').read_bytes()).hexdigest()
 version['contentHashes']['ll-sad']=hashlib.sha256((ROOT/SUB/'poslech/sad/index.html').read_bytes()).hexdigest()
 changes['version.json']=json.dumps(version,ensure_ascii=False,indent=2)+'\n'
 # Old R67 adapter intentionally supported only a B2/C1 subset. Six levels are now mandatory.
 changes['self-check/listening/listening-core.js']=unique(
  changes['self-check/listening/listening-core.js'],"(topic!=='ll-sad'||e.levels.join(',')==='B2,C1')",
  "(topic!=='ll-sad'||e.levels.join(',')==='A1,A2,B1,B2,C1,C2')",'SAD all-six runtime contract')
 changes['self-check/listening/listening-teacher.js']=unique(
  changes['self-check/listening/listening-teacher.js'],"levels:['B2','C1']","levels:['A1','A2','B1','B2','C1','C2']",'teacher CEFR menu')
 # Teacher key snapshot: replace only the SAD entry, not any of the 8 original sources.
 key=changes['self-check/practice-answers/teacher-key.js']
 sad_start=key.index('"id": "ll-sad"')
 before=key[:sad_start];after=key[sad_start:]
 pat='"levels": [\n   "B2",\n   "C1"\n  ]'
 # The actual JSON indentation in the snapshot is introduced by r67.patch_key().
 match=re.search(r'("levels"\s*:\s*\[)\s*"B2"\s*,\s*"C1"\s*(\])',after)
 if not match:raise ValueError('Missing teacher snapshot B2/C1 levels for SAD')
 after=after[:match.start()]+match.group(1)+'\n'+',\n'.join('    "'+x+'"' for x in LEVELS)+'\n  '+match.group(2)+after[match.end():]
 changes['self-check/practice-answers/teacher-key.js']=before+after
 # Separate release ID changes (the original HR2 test still verifies its SHA and contents).
 for rel in ['tests/r27-public-release.test.cjs','tests/r35-hr2-release.test.cjs']:
  changes[rel]=changes[rel].replace('R67-SAD-UNIFIED','R68-SAD-A1C2')
 # All numeric contracts now use the six new variants, never the two-variant R67 count.
 for rel in list(changes):
  if rel.startswith('tests/'):
   changes[rel]=swap_all_counts(changes[rel])
 r52=changes['tests/r52-resilient-teacher-key.test.cjs']
 r52=unique(r52,"e.id==='ll-sad'?['B2','C1']:['A1','A2','B1','B2','C1','C2']",
  "['A1','A2','B1','B2','C1','C2']",'all teacher levels equal')
 changes['tests/r52-resilient-teacher-key.test.cjs']=r52
 # The 30→31 count and 666→672 update is intentional. No original card contents are edited.
 changes['tests/r35-hr2-release.test.cjs']=unique(
  changes['tests/r35-hr2-release.test.cjs'],"0),672'));","0),672'));",'historic R24 - noop') if False else changes['tests/r35-hr2-release.test.cjs']
 # The main landing page description and counts come from R67/HR2 and are independent of level count.
 add_browser_guard(changes,repo)
 return changes

def preflight(repo):
 root=repo/SUB
 if not (root/'data/cards.json').exists():raise ValueError('Not an LSH checkout')
 catalog=json.loads((root/'data/cards.json').read_text('utf8'))
 if not(len(catalog['entries'])==30 and sum(len(e['languages'])*len(e['levels']) for e in catalog['entries'])==666 and
        any(e['id']=='cl-human-rights' for e in catalog['entries']) and
        not any(e['id']=='ll-sad' for e in catalog['entries'])):
  raise ValueError('GitHub baseline changed: expected exact HR2 main (30/666); ABORT and re-audit')
 for rel in COPIES:
  file=ROOT/SUB/rel
  if not file.is_file():raise ValueError('Missing R68 source '+rel)
  if (root/rel).exists():raise ValueError('Refuse to overwrite target '+rel)
 changes=integrate(repo)
 for rel in changes:
  if not (root/rel).is_file():raise ValueError('Missing target '+rel)
 # Sanity of generated catalog+metadata+hash at the boundary.
 cat=json.loads(changes['data/cards.json']);v=json.loads(changes['version.json']);i=json.loads(changes['data/catalog-i18n.json'])
 assert len(cat['entries'])==31 and v['topicCount']==31 and v['variantCount']==672
 assert sum(len(e['languages'])*len(e['levels']) for e in cat['entries'])==672
 assert len(i['entries'])==31 and len(v['contentHashes'])==31
 return changes

def main():
 arg=argparse.ArgumentParser(description=__doc__)
 arg.add_argument('--repo',type=Path,required=True,help='path to independent checked-out gh-rab.github.io working copy')
 arg.add_argument('--apply',action='store_true',help='apply to this local copy only, never GitHub')
 arg.add_argument('--backup-dir',type=Path)
 arg.add_argument('--write-diff',type=Path,help='write unified patch for review')
 a=arg.parse_args();repo=a.repo.resolve()
 changed=preflight(repo)
 if a.write_diff:
  output=[]
  for rel,new in sorted(changed.items()):
   old=read(repo,rel)
   output.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+str(SUB/rel),tofile='b/'+str(SUB/rel)))
  a.write_diff.parent.mkdir(parents=True,exist_ok=True)
  a.write_diff.write_text(''.join(output),encoding='utf-8')
 print('R68 DRY RUN / CHANGE PLAN: +%d new, ~%d updated' % (len(COPIES),len(changed)))
 print('Catalogue: 30→31, Listening 3→4, total variants 666→672, SAD EN A1–C2')
 for x in sorted(changed):print(' ~',SUB/x)
 for x in COPIES:print(' +',SUB/x)
 if not a.apply:
  print('No files changed. Pass --apply on a review branch to modify local files.')
  return
 destination=(a.backup_dir or ROOT/'INSTALL_AND_QA'/'backups'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')).resolve()
 if destination.is_relative_to(repo):raise ValueError('Backup destination must be outside target repo')
 # A fail-closed preparation step; only write after *all* patches have been computed.
 for rel in changed:
  p=destination/SUB/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/SUB/rel,p)
 for rel in COPIES:
  p=repo/SUB/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/SUB/rel,p)
 for rel,content in changed.items():
  (repo/SUB/rel).write_text(content,encoding='utf-8')
 print('LOCAL CHECKOUT PATCHED. Original files backed up:',destination)
 print('Mandatory: full node and Playwright CI; Chromium, WebKit and physical iPad; verify R64 merge conflicts before production.')
if __name__=='__main__':
 try:main()
 except Exception as e:
  print('FAIL-CLOSED / NO DEPLOY:',repr(e),file=sys.stderr);sys.exit(2)
