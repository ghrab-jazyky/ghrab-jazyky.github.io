#!/usr/bin/env python3
"""R67 canonical SAD -> shared LSH student, teacher and result engines.

Fail-closed, local-only integrator for an independent development checkout.
NO push, merge, deployment or writes until --apply. The historic 3 cards remain unchanged.
"""
from __future__ import annotations
import argparse,datetime,hashlib,importlib.util,json,re,shutil,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SUB=Path('language-skills-hub')
BASE=Path(__file__).resolve().parent/'r66_base_patch.py'
spec=importlib.util.spec_from_file_location('r66_base_patch',BASE)
base=importlib.util.module_from_spec(spec);sys.modules[spec.name]=base;spec.loader.exec_module(base)
base.BUNDLE=ROOT
# These are the only source files to be copied into the repository. The R66-only
# isolated TEST and teacher result pages are deliberately excluded/deprecated.
COPIES=[
 'poslech/sad/index.html',
 'poslech/sad/sad-core.js',
 'poslech/sad/sad-practice.js',
 'poslech/sad/sad.css',
 'tests/r67-sad-unified.test.cjs',
 'tests/r67-sad-unified.browser.test.cjs',
]

def one(s,before,after,what):
    n=s.count(before)
    if n==1:return s.replace(before,after,1)
    # R64 and HR2 have minor indentation differences: tolerate whitespace ONLY
    # when one unique structural match exists; never replace multiple occurrences.
    pieces=re.split(r'(\s+)',before)
    pattern=''.join(r'\s+' if x.isspace() else re.escape(x) for x in pieces if x)
    hits=list(re.finditer(pattern,s))
    if len(hits)!=1:raise ValueError(f'{what}: expected 1 unique source marker; exact={n}, whitespace-tolerant={len(hits)}')
    m=hits[0]
    return s[:m.start()]+after+s[m.end():]

def in_repo(repo,path):return (repo/SUB/path).read_text(encoding='utf-8')

def patch_core(src):
    src=one(src,
      "const TOPICS=Object.freeze(['ll-matthew-oscars','ll-harrison-ford','ll-peaky-no-fighting']);",
      "const TOPICS=Object.freeze(['ll-matthew-oscars','ll-harrison-ford','ll-peaky-no-fighting']);\n const ALL_TOPICS=Object.freeze([...TOPICS,'ll-sad']);",
      'Listening topic list (legacy retained)')
    src=one(src,"TOPICS.includes(topic),'Unknown Listening topic.'",
      "ALL_TOPICS.includes(topic),'Unknown Listening topic.'",'Listening catalog topic whitelist')
    src=one(src,
      "Array.isArray(e.levels)&&LEVELS.every(l=>e.levels.includes(l)),'Incomplete CEFR levels.'",
      "Array.isArray(e.levels)&&e.levels.length>0&&e.levels.every(l=>LEVELS.includes(l))&&\n     new Set(e.levels).size===e.levels.length&&\n     (topic!=='ll-sad'||e.levels.join(',')==='B2,C1'),'Invalid CEFR levels.'",
      'catalog CEFR subsets')
    src=one(src,
      "must(Array.isArray(v.sequence)&&v.sequence.length>=2&&v.sequence.length<=20&&\n     v.sequence.every(x=>nonempty(x,2500))&&new Set(v.sequence).size===v.sequence.length,",
      "must(Array.isArray(v.sequence)&&\n     (v.sequence.length===0&&v.matching||v.sequence.length>=2&&v.sequence.length<=20)&&\n     v.sequence.every(x=>nonempty(x,2500))&&new Set(v.sequence).size===v.sequence.length,",
      'optional reconstruction in matching-based listening')
    src=one(src,
      "must(Array.isArray(v[phase])&&v[phase].length>=1&&v[phase].length<=12,'Invalid writing tasks.');",
      "must(Array.isArray(v[phase])&&\n      (v[phase].length>=1&&v[phase].length<=12||phase==='facts'&&v.matching&&v[phase].length===0),\n      'Invalid writing tasks.');",
      'optional cloze facts in matching-based listening')
    src=one(src,
      "   return v;\n  }\n  function variant(data,level){",
      """   // R67: common Listening schema now accepts authentic one-to-one matching.
   // Old sequence/cloze variants retain their unchanged checks and scoring.
   if(v.matching!==undefined){
    const m=v.matching;
    must(plain(m)&&Array.isArray(m.options)&&m.options.length>=3&&m.options.length<=12&&
     m.options.every(x=>nonempty(x,1000))&&new Set(m.options).size===m.options.length&&
     Array.isArray(m.items)&&m.items.length>=2&&m.items.length<=12,
     'Invalid matching bank.');
    const rights=new Set();
    for(const q of m.items){
     must(plain(q)&&nonempty(q.title,2000)&&
      Number.isInteger(q.correct)&&q.correct>=0&&q.correct<m.options.length&&
      !rights.has(q.correct),'Invalid matching solution.');
     rights.add(q.correct);
    }
   }
   return v;
  }
  function variant(data,level){""",
      'matching validation (single shared schema)')
    src=one(src,
      "const normalized={gist:[],detail:[],sequence:[],facts:[],open:[]};",
      "const normalized={gist:[],detail:[],sequence:[],matching:[],facts:[],open:[]};",
      'matching answer shape')
    src=one(src,
      "   for(const part of ['facts','open']){\n    const arr=a[part]===undefined?[]:a[part];",
      """   const match=v.matching?.items||[],candidate=a.matching===undefined?[]:a.matching;
   must(Array.isArray(candidate)&&candidate.length<=match.length,'Invalid matching answers.');
   const matchUsed=new Set();
   for(let i=0;i<match.length;i++){
    const x=candidate[i];
    must(x===null||x===undefined||(Number.isInteger(x)&&x>=0&&x<v.matching.options.length),
     'Invalid matching letter.');
    if(Number.isInteger(x)){must(!matchUsed.has(x),'Matching answer used more than once.');matchUsed.add(x)}
    normalized.matching[i]=Number.isInteger(x)?x:null;
   }
   for(const part of ['facts','open']){
    const arr=a[part]===undefined?[]:a[part];""",
      'normalize matching and prevent duplicate letters')
    src=one(src,
      "   const writing=[];\n   for(const part of ['facts','open'])",
      """   const matching=v.matching?.items||[];
   for(let i=0;i<matching.length;i++){
    const q=matching[i],value=a.matching[i],filled=value!==null,ok=filled&&value===q.correct;
    if(ok)correct++;
    if(filled)answered++;
    reviewed.push({phase:'matching',number:i+1,question:q.title,
     answered:filled,correct:!!ok,
     chosen:filled?[v.matching.options[value]]:[],
     correctAnswers:[v.matching.options[q.correct]],reason:typeof q.why==='string'?q.why:''});
   }
   const writing=[];
   for(const part of ['facts','open'])""",
      'assess matching with original answer bank')
    src=one(src,
      "const objectiveMax=v.gist.length+v.detail.length+v.sequence.length;",
      "const objectiveMax=v.gist.length+v.detail.length+v.sequence.length+\n    (v.matching?.items.length||0);",
      'matching objective points')
    src=one(src,
      "must(TOPICS.includes(topic)&&LEVELS.includes(level),'Unknown cloze topic or level.');",
      "must(ALL_TOPICS.includes(topic)&&LEVELS.includes(level),'Unknown cloze topic or level.');\n   if(v.facts.length===0)return [];",
      'zero-cloze listening preserves 17-point score')
    src=one(src,
      "'www.netflix.com'].includes(parsed.hostname)",
      "'www.netflix.com','ed.ted.com'].includes(parsed.hostname)",
      'official TED-Ed media whitelist')
    src=one(src,
      "const api={LEVELS,TOPICS,PHASES,extractJson,catalogEntry,variant,validate,",
      "const api={LEVELS,TOPICS,ALL_TOPICS,PHASES,extractJson,catalogEntry,variant,validate,",
      'new topic exposed to shared runtime')
    return src

def patch_student(src):
    src=one(src,"const answers={gist:[],detail:[],sequence:[],cloze:[]};",
      "const answers={gist:[],detail:[],sequence:[],matching:[],cloze:[]};",'student matching answers')
    src=one(src,
      "const totalTasks=()=>chosen.gist.length+chosen.detail.length+chosen.sequence.length+\n   chosen.facts.length;",
      "const totalTasks=()=>chosen.gist.length+chosen.detail.length+chosen.sequence.length+\n   chosen.facts.length+(chosen.matching?.items.length||0);",
      'student progress denominator')
    src=one(src,
      "for(const x of answers.sequence)if(Number.isInteger(x))n++;",
      "for(const x of answers.sequence)if(Number.isInteger(x))n++;\n   for(const x of answers.matching)if(Number.isInteger(x))n++;",
      'student matching progress')
    src=one(src,
      "  function render(){\n   const list=$('taskList');",
      """  function matching(){
   const list=$('taskList'),data=chosen.matching;
   if(!data?.items.length)return;
   list.appendChild(element('p','quiz-hint',
    'C. Match each statement with one explanation. Each explanation may be used once; two are extra.'));
   const bank=element('section','sequence-bank');
   bank.setAttribute('aria-label','Matching explanation bank');
   for(const option of data.options)bank.appendChild(element('p',null,option));
   list.appendChild(bank);
   for(let i=0;i<data.items.length;i++){
    const task=data.items[i],row=element('div','sequence-row'),id='matching-'+i;
    const label=element('label',null,(i+1)+'. '+task.title);label.htmlFor=id;
    const select=element('select','select-response');select.id=id;
    select.setAttribute('aria-label','Matching explanation '+(i+1));
    const empty=element('option',null,'— Select an explanation —');empty.value='';select.appendChild(empty);
    for(let k=0;k<data.options.length;k++){
     const option=element('option',null,data.options[k]);option.value=String(k);select.appendChild(option);
    }
    select.addEventListener('change',()=>{
     if(submitted)return;
     const picked=select.value===''?null:Number(select.value);
     if(Number.isInteger(picked))for(let j=0;j<data.items.length;j++)if(j!==i&&answers.matching[j]===picked){
      answers.matching[j]=null;const other=$('matching-'+j);if(other)other.value='';
     }
     answers.matching[i]=picked;
     progress();timedUI?.save();
    });
    row.append(label,select);list.appendChild(row);
   }
  }
  function render(){
   const list=$('taskList');""",
      'shared native matching UI')
    src=one(src,
      "list.appendChild(heading(phases[2]));\n   sequence();\n   clozeTask();",
      """if(chosen.sequence.length||chosen.facts.length){
    list.appendChild(heading(phases[2]));
    if(chosen.sequence.length)sequence();
    if(chosen.facts.length)clozeTask();
   }
   if(chosen.matching?.items.length){
    list.appendChild(heading({id:'listen-matching',heading:'Listen, Match and Explain',
     caption:'Targeted replay – connect each observation to the right scientific explanation.'}));
    matching();
   }""",
      'render only meaningful third-stage tasks')
    src=one(src,
      "'ll-peaky-no-fighting':'Peaky Blinders · No Fighting'",
      "'ll-peaky-no-fighting':'Peaky Blinders · No Fighting',\n    'll-sad':'Seasonal Affective Disorder · TED-Ed'",
      'SAD shared test title')
    src=one(src,
      "'All choices, sequencing and factual cloze answers are scored automatically.",
      "'All choices, matching, sequencing and factual cloze answers are scored automatically.",
      'result mode wording')
    src=one(src,
      "phase==='detail'?'Listen and Interpret':'Listen, Complete and Reconstruct';",
      "phase==='detail'?'Listen and Interpret':\n    phase==='matching'?'Listen, Match and Explain':'Listen, Complete and Reconstruct';",
      'matching result phase')
    src=one(src,
      "task.phase==='sequence'?chosen.sequence:undefined;",
      "task.phase==='sequence'?chosen.sequence:\n      task.phase==='matching'?chosen.matching?.options:undefined;",
      'full PDF matching options')
    src=one(src,
      "task.phase==='sequence'?'RECONSTRUCTION':'FACTUAL CLOZE'",
      "task.phase==='sequence'?'RECONSTRUCTION':task.phase==='matching'?'MATCHING':'FACTUAL CLOZE'",
      'full PDF matching phase')
    src=one(src,
      "const usedSequence=new Set();",
      """const usedMatch=new Set();
      for(let i=0;i<(chosen.matching?.items.length||0);i++){
       const value=saved.matching?.[i];
       if(!Number.isInteger(value)||value<0||value>=chosen.matching.options.length||usedMatch.has(value))continue;
       usedMatch.add(value);answers.matching[i]=value;
       const sel=$('matching-'+i);if(sel)sel.value=String(value);
      }
      const usedSequence=new Set();""",
      'restore matching test after reload')
    return src

def patch_key(src,entry):
    src=one(src,
      "groups.push(group('Reconstruction – správné pořadí',variant.sequence.map((sentence,i)=>\n   item('Pozice '+(i+1),sentence))));",
      """groups.push(group('Reconstruction – správné pořadí',variant.sequence.map((sentence,i)=>
   item('Pozice '+(i+1),sentence))));
 if(variant.matching?.items.length)groups.push(group('Matching – explanations',
  variant.matching.items.map(q=>item(q.title,variant.matching.options[q.correct],q.why||''))));""",
      'practice key for native matching')
    src=one(src,
      """return {kind:L,skill:'listening',topicId:entry.id,topic:entry.title,
  language:lang,level,groups,mode:'practice'};""",
      """return {kind:L,skill:'listening',topicId:entry.id,topic:entry.title,
  language:lang,level,groups:groups.filter(g=>g.items.length>0),mode:'practice'};""",
      'practice key filter unavailable phases')
    # For the TEST, insert match group after reconstruction.
    src=one(src,
      "groups.push(group('C · Reconstruction – test',variant.sequence.map((sentence,i)=>\n  item('Position '+(i+1),sentence))));",
      """groups.push(group('C · Reconstruction – test',variant.sequence.map((sentence,i)=>
  item('Position '+(i+1),sentence))));
 if(variant.matching?.items.length)groups.push(group('C · Matching – test',
  variant.matching.items.map(q=>item(q.title,variant.matching.options[q.correct],q.why||''))));""",
      'TEST key matching')
    src=one(src,
      """return {kind:L,skill:'listening',topicId:entry.id,topic:entry.title,
  language:lang,level,groups,mode:'test'};
}
function validate(model){""",
      """return {kind:L,skill:'listening',topicId:entry.id,topic:entry.title,
  language:lang,level,groups:groups.filter(g=>g.items.length>0),mode:'test'};
}
function validate(model){""",
      'TEST key filter absent phases')
    # Inject the topic in the SAME public snapshot, for teacher key in the SAME URL.
    mark='\n].map(e=>Object.freeze({...e,'
    newentry=json.dumps(entry,ensure_ascii=False,indent=2)
    src=one(src,mark,',\n '+newentry+'\n'+mark,'nine key entry snapshot')
    src=one(src,"need(entries.length===8,'Neúplná metadata Reading/Listening.');",
      "need(entries.length===9,'Neúplná metadata Reading/Listening.');",'9 fixed-topic teacher keys')
    return src

def integrated(repo):
    result=base.patch(repo)
    # Remove R66's bespoke teacher results route. All Listening uses one `VÝSLEDKY` URL.
    js=result['assets/hub.js']
    js=one(js,""" if(e.id==='ll-sad'){
  const url=new URL('poslech/sad/teacher-key.html',document.baseURI);
  const level=byId('level').value;
  if(e.levels.includes(level))url.searchParams.set('level',level);
  return url.href;
 }""",'', 'remove bespoke SAD teacher key URL')
    result['assets/hub.js']=js
    teacher=result['self-check/listening/listening-teacher.js']
    teacher=one(teacher,"const u=new URL(topicId==='ll-sad'?'sad-student.html':'student.html',location.href);",
      "const u=new URL('student.html',location.href);",'remove bespoke SAD test URL')
    result['self-check/listening/listening-teacher.js']=teacher
    # Original R66 installer changes a legacy test to require the now retired page.
    r53=result['tests/r53-listening-fixed-topic-video.test.cjs']
    r53=one(r53,r'assert.match(js,/sad-student\.html/);',
      r"assert.match(js,/new URL\('student\.html',location\.href\)/);",'restore all topics to generic student')
    result['tests/r53-listening-fixed-topic-video.test.cjs']=r53
    # The old 3 topics and their exact data remain cryptographically pinned.
    result['self-check/listening/listening-core.js']=patch_core(in_repo(repo,'self-check/listening/listening-core.js'))
    result['self-check/listening/listening-student.js']=patch_student(in_repo(repo,'self-check/listening/listening-student.js'))
    catalog=json.loads(result['data/cards.json'])
    sad=next(x for x in catalog['entries'] if x['id']=='ll-sad')
    result['self-check/practice-answers/teacher-key.js']=patch_key(in_repo(repo,'self-check/practice-answers/teacher-key.js'),sad)
    version=json.loads(result['version.json'])
    version['version']='R67-SAD-UNIFIED'
    version['contentHashes']['ll-sad']=hashlib.sha256((ROOT/SUB/'poslech/sad/index.html').read_bytes()).hexdigest()
    version['listeningSharedMatchingEnabled']=True
    version['sadArchitecture']='ONE_PUBLIC_HTML_DATA; COMMON_LISTENING_STUDENT; COMMON_TEACHER_KEY; MATCHING_EXT'
    result['version.json']=json.dumps(version,ensure_ascii=False,indent=2)+'\n'
    # Core integrity and legacy tests: change only numeric contracts, never remove
    # original SHA assertions. New topic bank is checked independently by R67 tests.
    r27=result['tests/r27-public-release.test.cjs']
    result['tests/r27-public-release.test.cjs']=one(r27,"manifest.version,'R35-HR2'",
     "manifest.version,'R67-SAD-UNIFIED'",'R27 release identifier')
    hr=result['tests/r35-hr2-release.test.cjs']
    result['tests/r35-hr2-release.test.cjs']=one(hr,"version.version,'R35-HR2'",
     "version.version,'R67-SAD-UNIFIED'",'HR2 base retained in R67')
    # Historic snapshot and count checks recognize the fourth Listening topic.
    r52=result['tests/r52-resilient-teacher-key.test.cjs']
    r52=one(r52,"entries.filter(e=>['cteni','poslech'].includes(e.skill)&&e.id!=='ll-sad')",
      "entries.filter(e=>['cteni','poslech'].includes(e.skill))",'R52 expected snapshot includes SAD')
    r52=one(r52,'model.keyEntries.length,8','model.keyEntries.length,9','teacher snapshot count')
    r52=one(r52,"x.skill==='poslech').length,3","x.skill==='poslech').length,4",'teacher Listening count')
    r52=one(r52,"assert.deepEqual(e.levels,['A1','A2','B1','B2','C1','C2']);",
      "assert.deepEqual(e.levels,e.id==='ll-sad'?['B2','C1']:['A1','A2','B1','B2','C1','C2']);",'teacher SAD subset')
    result['tests/r52-resilient-teacher-key.test.cjs']=r52
    # R67's shared key replaces the old isolated teacher and student scripts;
    # all older `r65` tests remain in the package only, never installed.
    return result

def preflight(repo):
    if not (repo/SUB/'data/cards.json').exists():raise ValueError('Not an LSH repository: data/cards.json missing')
    # Guard against concurrent changes in the repository after the base audit.
    c=json.loads(in_repo(repo,'data/cards.json'))
    if len(c['entries'])!=30 or not any(e['id']=='cl-human-rights' for e in c['entries']):
        raise ValueError('This integration is pinned to HR2 main (30 topics); update and audit the base first')
    if any(e['id']=='ll-sad' for e in c['entries']):raise ValueError('SAD already present; abort, do not overwrite')
    for item in COPIES:
        if not (ROOT/SUB/item).is_file():raise ValueError('Package incomplete: '+item)
    # No extra files are copied: especially no secondary `sad-student.html`.
    return integrated(repo)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--apply',action='store_true')
    ap.add_argument('--backup-dir',type=Path)
    ap.add_argument('--write-diff',type=Path,help='Write reviewable unified diff for changed existing files')
    args=ap.parse_args()
    repo=args.repo.resolve()
    changes=preflight(repo)
    if args.write_diff:
        import difflib
        diff=[]
        for rel,new in sorted(changes.items()):
            before=in_repo(repo,rel)
            diff.extend(difflib.unified_diff(before.splitlines(keepends=True),new.splitlines(keepends=True),
                fromfile='a/'+str(SUB/rel),tofile='b/'+str(SUB/rel)))
        args.write_diff.parent.mkdir(parents=True,exist_ok=True)
        args.write_diff.write_text(''.join(diff),encoding='utf-8')
    print('R67 shared Listening install: existing files to modify='+str(len(changes))+'; new='+str(len(COPIES)))
    print('Expected 31 topics / 668 variants / 4 Listening (B2 and C1 for SAD).')
    for path in sorted(changes):print(' ~',SUB/path)
    for path in sorted(COPIES):print(' +',SUB/path)
    if not args.apply:
        print('DRY RUN: no repository files changed.')
        return
    back=(args.backup_dir or (ROOT/'INSTALL_AND_QA'/'backups'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S'))).resolve()
    if back.is_relative_to(repo):raise ValueError('Backup must be outside the repository')
    for relative in changes:
        dst=back/SUB/relative;dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(repo/SUB/relative,dst)
    for relative in COPIES:
        dst=repo/SUB/relative
        if dst.exists():raise ValueError('Do not overwrite an existing file: '+str(dst))
    for relative in COPIES:
        target=repo/SUB/relative;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(ROOT/SUB/relative,target)
    for relative,text in changes.items():
        path=repo/SUB/relative
        path.write_text(text,encoding='utf-8')
    print('LOCAL APPLY DONE; backups:',back)
    print('Run node --test tests/*.test.cjs, Playwright in Chromium and WebKit, physical iPad. DO NOT DEPLOY pending GO.')

if __name__=='__main__':
    try: main()
    except Exception as exc:
        sys.stderr.write('R67 FAIL-CLOSED: '+str(exc)+'\n');sys.exit(1)
