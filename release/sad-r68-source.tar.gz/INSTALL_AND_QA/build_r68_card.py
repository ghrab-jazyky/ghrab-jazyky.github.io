#!/usr/bin/env python3
"""Deterministic, auditable R68 card generator; preserve 2026-11-09 B2 bank."""
from __future__ import annotations
import json,re,hashlib,base64,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'language-skills-hub/poslech/sad'
AUTHOR=json.loads((ROOT/'AUTHORING/sad-R68-A1-C2.json').read_text(encoding='utf-8'))
LEVELS=AUTHOR['levels']
assert LEVELS==['A1','A2','B1','B2','C1','C2']
orig=AUTHOR['meta']
DATA={**orig,'kind':'LSH_SAD_LISTENING_A1C2_V2','levels':LEVELS,'bankId':'SAD-R68-A1C2-20261114',
'questionBank':copy.deepcopy(AUTHOR['variants']['B2']['questionBank']),
'matchingBank':copy.deepcopy(AUTHOR['variants']['B2']['matchingBank']),
'assessmentNote':'Each CEFR level has a different 17-item bank; original B2 bank preserved exactly.',
'practice':AUTHOR['practice'],'variants':AUTHOR['variants']}
letters='ABCDEFG'
references={
'A1':['Light reaches the brain from the eyes and helps the body clock. Melatonin is related to sleep.','Light therapy is one possible treatment, but people should ask a health professional for guidance.'],
'A2':['Signals from light-sensitive cells help the body clock organise sleep and daily functions.','The video mentions talking therapy and light therapy; professional advice is needed for safe light therapy.'],
'B1':['Ordinary seasonal tiredness is common. SAD involves recurring depressive episodes that seriously affect a person.','The video discusses possible changes in melatonin release and changes in body-clock timing, but neither is proven as the only cause.'],
'B2':['The brain uses daylight cues to organise circadian rhythms; the link between those rhythms and mood is still being researched.','The narrator presents several potential causes and interventions, but does not identify one proven explanation for every person.'],
'C1':['A circadian hypothesis specifies a plausible timing mechanism, but a coherent mechanism alone does not demonstrate causation of severe mood symptoms.','To test a circadian theory, compare measured internal timing and mood changes while addressing alternative explanations and confounding variables.'],
'C2':['A rigorous study would assess temporal rhythms and clinical outcomes prospectively, while accounting for sleep routines, seasonal exposure and psychosocial confounders.','Incomplete etiological knowledge does not logically prevent clinical interventions; treatment can rest on evidence of benefit and harm independent of a final causal model.']}
for level in LEVELS:
 bank=AUTHOR['variants'][level]; support=DATA['practice'][level]
 assert len(bank['questionBank'])==17 and len(bank['matchingBank'])==7
 obj={'goal':support['objective'],'before':support['pre'],'prediction':'Before listening: What can daylight tell us about sleep and mood?',
      'gist':[],'detail':[],'sequence':[],'matching':{'options':[f'{code} — {meaning}' for code,meaning in bank['matchingBank']], 'items':[]},
      'facts':[],
      'open':[{'title':question,'answer':references[level][i] if i<len(references[level]) else 'Answers should be supported by the video.',
       'criteria':'Assess source-supported reasoning; no personal medical disclosure.'} for i,question in enumerate(support['after'])],
      'vocab':[{'term':row['term'],'meaning':row['cs']+' · '+row['meaning']} for row in support['vocabulary']],
      'talk':support['after'],'bankVersion':DATA['bankId']+'-'+level,'assessmentNote':'One independent 17-item bank for '+level}
 for q in bank['questionBank']:
  if q['type']=='mc':obj['gist'].append({'id':q['id'],'title':q['question'],'type':'single','options':q['options'],'correct':letters.index(q['correct']),'why':q['explanation'],'evidence':q['evidence']})
  elif q['type']=='tns':obj['detail'].append({'id':q['id'],'title':q['question'],'type':'single','options':['TRUE','FALSE','NOT STATED'],'correct':['TRUE','FALSE','NOT STATED'].index(q['correct']),'why':q['explanation'],'evidence':q['evidence']})
  elif q['type']=='match':obj['matching']['items'].append({'id':q['id'],'title':q['question'],'correct':letters.index(q['correct']),'why':q['explanation'],'evidence':q['evidence']})
  else:raise RuntimeError(q['id'])
 assert len(obj['gist'])==6 and len(obj['detail'])==6 and len(obj['matching']['items'])==5
 DATA[level]=obj
jsonline=json.dumps(DATA,ensure_ascii=False,separators=(',',':'))
SOURCES={'youtube':orig['video'],'teded':orig['source']}
script='const DATA='+jsonline+';\nconst SOURCES='+json.dumps(SOURCES,ensure_ascii=False,separators=(',',':'))+';'
digest=base64.b64encode(hashlib.sha256(script.encode('utf-8')).digest()).decode('ascii')
card=SRC/'index.html'
html=card.read_text('utf-8')
html,count=re.subn(r'<script>const DATA=.*?</script>','<script>'+script+'</script>',html,flags=re.S)
assert count==1
html,n=re.subn(r"script-src 'self' 'sha256-[^']+';", "script-src 'self' 'sha256-"+digest+"';",html);assert n==1
html=html.replace('B2/C1','A1–C2').replace('B2–C1','A1–C2').replace('B2 and C1 use the same original 17 objective items; level-specific extension tasks differ.','Each CEFR level has its own questions and age-appropriate extension tasks.')
html=html.replace('English · B2/C1','English · A1–C2')
html=html.replace('approximately 25–35 min','approximately 25–35 min')
buttons=''.join(f'<button type="button" data-level="{l}" aria-pressed="{"true" if l=="B2" else "false"}">{l}</button>' for l in LEVELS)
html,n=re.subn(r'(<div class="levels" id="levelPills"[^>]*>).*?(<span class="chip">Selected:)',
               lambda m:m.group(1)+buttons+m.group(2),html,flags=re.S)
assert n==1,'level selector not uniquely found'
card.write_text(html,encoding='utf-8')
# Source bank JSON is reproducible, no external content or copyrighted transcripts.
(ROOT/'AUTHORING/sad-R68-COMPILED-REFERENCE.json').write_text(json.dumps(DATA,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('R68 card:',len(html.encode('utf-8')),'bytes; JSON:',len(jsonline.encode('utf-8')),'bytes; levels:',LEVELS,'CSP sha256:',digest)
